import {
  TextField,
  Button,
  Paper,
  Grid,
  Typography,
} from "@mui/material";

function CustomerForm({
  form,
  handleChange,
  saveCustomer,
  editId,
}) {
  return (
    <Paper sx={{ p: 3, mb: 3 }}>
      <Typography variant="h6" mb={3}>
        {editId ? "Mijozni tahrirlash" : "Yangi mijoz"}
      </Typography>

      <form onSubmit={saveCustomer}>
        <Grid container spacing={2}>

          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label="F.I.Sh"
              name="name"
              value={form.name}
              onChange={handleChange}
              required
            />
          </Grid>

          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label="Telefon"
              name="phone"
              value={form.phone}
              onChange={handleChange}
            />
          </Grid>

          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label="Manzil"
              name="address"
              value={form.address}
              onChange={handleChange}
            />
          </Grid>

          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label="Obyekt"
              name="object"
              value={form.object}
              onChange={handleChange}
            />
          </Grid>

          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              type="number"
              label="Qarz"
              name="debt"
              value={form.debt}
              onChange={handleChange}
            />
          </Grid>

          <Grid item xs={12}>
            <Button
              variant="contained"
              type="submit"
              size="large"
            >
              {editId ? "Yangilash" : "Saqlash"}
            </Button>
          </Grid>

        </Grid>
      </form>
    </Paper>
  );
}

export default CustomerForm;