import { NavLink } from "react-router-dom";

import {
  FaHome,
  FaUsers,
  FaBoxOpen,
  FaVideo,
  FaShoppingCart,
  FaClipboardList,
  FaWarehouse,
  FaTools,
  FaMoneyBillWave,
  FaChartBar,
  FaCog,
  FaShieldAlt,
} from "react-icons/fa";


const menu = [
  {
    title: "Dashboard",
    path: "/",
    icon: <FaHome />
  },

  {
    title: "Mijozlar",
    path: "/customers",
    icon: <FaUsers />
  },

  {
    title: "Mahsulotlar",
    path: "/products",
    icon: <FaBoxOpen />
  },

  {
    title: "Kameralar",
    path: "/cameras",
    icon: <FaVideo />
  },

  {
    title: "Sotuvlar",
    path: "/sales",
    icon: <FaShoppingCart />
  },

  {
    title: "Buyurtmalar",
    path: "/orders",
    icon: <FaClipboardList />
  },

  {
    title: "Ombor",
    path: "/warehouse",
    icon: <FaWarehouse />
  },

  {
    title: "Servis",
    path: "/services",
    icon: <FaTools />
  },

  {
    title: "Xarajatlar",
    path: "/expenses",
    icon: <FaMoneyBillWave />
  },

  {
    title: "Hisobotlar",
    path: "/reports",
    icon: <FaChartBar />
  },

  {
    title: "Sozlamalar",
    path: "/settings",
    icon: <FaCog />
  },
];


function Sidebar() {

  return (

    <aside
      style={{
        width: "260px",
        minHeight: "100vh",
        background: "#0F172A",
        color: "#fff",
        display: "flex",
        flexDirection: "column",
      }}
    >


      <div
        style={{
          padding:"25px",
          textAlign:"center",
          borderBottom:"1px solid #334155"
        }}
      >

        <FaShieldAlt size={42} color="#38BDF8"/>

        <h2>
          SAFE HOME
        </h2>

        <p
          style={{
            color:"#94A3B8"
          }}
        >
          SERVICES ERP
        </p>

      </div>



      <div
        style={{
          padding:"20px 15px",
          flex:1
        }}
      >

        {
          menu.map((item)=>(

            <NavLink

              key={item.path}

              to={item.path}

              style={({isActive})=>({

                display:"flex",

                alignItems:"center",

                gap:"14px",

                padding:"14px",

                marginBottom:"10px",

                borderRadius:"10px",

                textDecoration:"none",

                color:"#fff",

                background:isActive
                ? "#2563EB"
                : "transparent"

              })}

            >

              <span>
                {item.icon}
              </span>

              <span>
                {item.title}
              </span>


            </NavLink>

          ))
        }


      </div>



      <div
        style={{
          padding:"15px",
          textAlign:"center",
          borderTop:"1px solid #334155",
          color:"#94A3B8"
        }}
      >

        SAFE HOME SERVICES ERP

        <br/>

        Version 1.0

      </div>


    </aside>

  );

}


export default Sidebar;