import { DataGrid } from "@mui/x-data-grid";
import { Button, Stack } from "@mui/material";

function CustomerTable({ customers, editCustomer, deleteCustomer }) {
  const columns = [
    {
      field: "name",
      headerName: "F.I.Sh",
      flex: 1,
    },
    {
      field: "phone",
      headerName: "Telefon",
      flex: 1,
    },
    {
      field: "address",
      headerName: "Manzil",
      flex: 1,
    },
    {
      field: "object",
      headerName: "Obyekt",
      flex: 1,
    },
    {
      field: "debt",
      headerName: "Qarz",
      flex: 1,
      renderCell: (params) => (
        <span
          style={{
            color:
              Number(params.value) > 0 ? "red" : "green",
            fontWeight: "bold",
          }}
        >
          {Number(params.value).toLocaleString()} so'm
        </span>
      ),
    },
    {
      field: "actions",
      headerName: "Amallar",
      flex: 1,
      sortable: false,
      renderCell: (params) => (
        <Stack direction="row" spacing={1}>
          <Button
            variant="contained"
            size="small"
            onClick={() => editCustomer(params.row)}
          >
            Edit
          </Button>

          <Button
            variant="outlined"
            color="error"
            size="small"
            onClick={() => deleteCustomer(params.row.id)}
          >
            Delete
          </Button>
        </Stack>
      ),
    },
  ];

  return (
    <div style={{ height: 600, width: "100%" }}>
      <DataGrid
        rows={customers}
        columns={columns}
        pageSizeOptions={[5, 10, 20, 50]}
        initialState={{
          pagination: {
            paginationModel: {
              pageSize: 10,
            },
          },
        }}
      />
    </div>
  );
}

export default CustomerTable;