import { useEffect, useState } from "react";
import API from "../api";

function Products() {
  const [products, setProducts] = useState([]);

  const [form, setForm] = useState({
    name: "",
    model: "",
    serial_number: "",
    purchase_price: "",
    sale_price: "",
    quantity: "",
  });

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      const res = await API.get("/products/");
      setProducts(res.data);
    } catch (err) {
      console.log(err);
    }
  };

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const addProduct = async (e) => {
    e.preventDefault();

    try {
      await API.post("/products/", form);

      setForm({
        name: "",
        model: "",
        serial_number: "",
        purchase_price: "",
        sale_price: "",
        quantity: "",
      });

      loadProducts();
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <div style={{ padding: "30px" }}>
      <h2>Mahsulotlar</h2>

      <form
        onSubmit={addProduct}
        style={{
          display: "grid",
          gap: "10px",
          maxWidth: "450px",
          marginBottom: "30px",
        }}
      >
        <input
          name="name"
          placeholder="Mahsulot nomi"
          value={form.name}
          onChange={handleChange}
          required
        />

        <input
          name="model"
          placeholder="Model"
          value={form.model}
          onChange={handleChange}
        />

        <input
          name="serial_number"
          placeholder="Serial Number"
          value={form.serial_number}
          onChange={handleChange}
        />

        <input
          name="quantity"
          type="number"
          placeholder="Soni"
          value={form.quantity}
          onChange={handleChange}
        />

        <input
          name="purchase_price"
          type="number"
          placeholder="Sotib olish narxi"
          value={form.purchase_price}
          onChange={handleChange}
        />

        <input
          name="sale_price"
          type="number"
          placeholder="Sotish narxi"
          value={form.sale_price}
          onChange={handleChange}
        />

        <button type="submit">Saqlash</button>
      </form>

      <table
        border="1"
        cellPadding="10"
        style={{
          width: "100%",
          borderCollapse: "collapse",
        }}
      >
        <thead>
          <tr>
            <th>#</th>
            <th>Nomi</th>
            <th>Model</th>
            <th>Serial Number</th>
            <th>Soni</th>
            <th>Olish narxi</th>
            <th>Sotish narxi</th>
            <th>Foyda</th>
          </tr>
        </thead>

        <tbody>
          {products.length === 0 ? (
            <tr>
              <td colSpan="8" align="center">
                Hozircha mahsulot yo'q
              </td>
            </tr>
          ) : (
            products.map((item, index) => (
              <tr
                key={item.id}
                style={{
                  backgroundColor: item.quantity <= 5 ? "#ffe5e5" : "white",
                }}
              >
                <td>{index + 1}</td>
                <td>{item.name}</td>
                <td>{item.model}</td>
                <td>{item.serial_number}</td>
                <td>{item.quantity}</td>
                <td>{item.purchase_price}</td>
                <td>{item.sale_price}</td>
                <td>{item.sale_price - item.purchase_price}</td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export default Products;