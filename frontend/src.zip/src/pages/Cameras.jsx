function Cameras(){

  return (
    <div style={{padding:"30px"}}>
      <h1>📷 Kameralar</h1>
      <p>Kamera moduli ishlayapti</p>
    </div>
  );

}

export default Cameras;