import { useEffect, useState } from "react";
import API from "../api";

import CustomerStats from "../components/CustomerStats";
import CustomerForm from "../components/CustomerForm";
import CustomerTable from "../components/CustomerTable";

function Customers() {
  const [customers, setCustomers] = useState([]);

  const [form, setForm] = useState({
    name: "",
    phone: "",
    address: "",
    object: "",
    debt: 0,
  });

  const [editId, setEditId] = useState(null);

  const loadCustomers = async () => {
    try {
      const res = await API.get("/customers");
      setCustomers(res.data);
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    loadCustomers();
  }, []);

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const saveCustomer = async (e) => {
    e.preventDefault();

    try {
      if (editId) {
        await API.put(`/customers/${editId}`, form);
      } else {
        await API.post("/customers", form);
      }

      setForm({
        name: "",
        phone: "",
        address: "",
        object: "",
        debt: 0,
      });

      setEditId(null);

      loadCustomers();
    } catch (err) {
      console.log(err);
    }
  };

  const editCustomer = (item) => {
    setEditId(item.id);

    setForm({
      name: item.name,
      phone: item.phone,
      address: item.address,
      object: item.object,
      debt: item.debt,
    });
  };

  const deleteCustomer = async (id) => {
    if (!window.confirm("Mijoz o'chirilsinmi?")) return;

    try {
      await API.delete(`/customers/${id}`);
      loadCustomers();
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <div className="p-6">
      <CustomerStats customers={customers} />

      <CustomerForm
        form={form}
        handleChange={handleChange}
        saveCustomer={saveCustomer}
        editId={editId}
      />

      <CustomerTable
        customers={customers}
        editCustomer={editCustomer}
        deleteCustomer={deleteCustomer}
      />
    </div>
  );
}

export default Customers;